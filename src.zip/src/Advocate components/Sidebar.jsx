
// Sidebar removed as per new design/theme
const Sidebar = () => null;

export default Sidebar;